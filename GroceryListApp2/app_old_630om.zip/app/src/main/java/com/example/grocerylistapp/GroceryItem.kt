package com.example.grocerylistapp

data class GroceryItem(val name: String, val category: String, val type: String)
