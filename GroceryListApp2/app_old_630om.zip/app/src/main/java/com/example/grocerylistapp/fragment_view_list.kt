package com.example.grocerylistapp

class fragment_view_list {
}