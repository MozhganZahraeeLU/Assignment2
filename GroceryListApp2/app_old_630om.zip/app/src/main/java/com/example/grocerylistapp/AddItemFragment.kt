package com.example.grocerylistapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class AddItemFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add_item, container, false)

        val addItemButton: Button = view.findViewById(R.id.add_item_button)
        val itemEditText: EditText = view.findViewById(R.id.item_edit_text)

        addItemButton.setOnClickListener {
            val itemName = itemEditText.text.toString()
            if (itemName.isNotEmpty()) {
                // Handle adding the item to the list (e.g., save to a database or a shared preference)
                Toast.makeText(context, "Item added: $itemName", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Please enter an item name", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
}
